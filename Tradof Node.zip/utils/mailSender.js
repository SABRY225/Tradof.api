
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  host: "smtp.gmail.com",
  port: 465,
  secure: true, // true for port 465, false for other ports
  auth: {
    user: 'ahmedsabrymahmoud225@gmail.com',
    pass: 'tlrvktzjnbrzdgbn',
  },
});


const SendMail = async(email,otp)=>{
    await transporter.sendMail({
        from: email, // sender address
        to: 'ahmedsabrymahmoud225@gmail.com', // list of receivers
        subject: "Technical Support", // Subject line
        html: `otp is ${otp}`, // html body
    });
}

module.exports={SendMail}